/* This is where we put our global variables */
var errors = [];
var errorDist = [0];
var questions = parseInt(document.getElementById("questions").value);
var min = parseInt(document.getElementById("min").value);
var max = parseInt(document.getElementById("max").value);